function tocaSomPom(idElementoAudio){
    document.querySelector(idElementoAudio).play();
}

const listaDeTeclas = document.querySelectorAII('tecla');

//para
for (let contator = 0; contator <listaDeTeclas.length; contador++){

    const tecla = listaDeTeclas[contador];
    const instrumento = tecla.classList[1];
    const isAudio = '#som_${instrumento}';//templete string
    
    tecla.onclick = function() {
        tocaSomPom(idAudio);
    }
    
}